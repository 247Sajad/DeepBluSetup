import LeftNav from './LeftNav'
import React, { useState, useEffect } from 'react' // , { useState }
import { useQuery, gql } from '@apollo/client';
import { Link } from "react-router-dom";

const svgFor = (n) => {
  switch (true) {
    case n > 0:
      return (
        <svg
          viewBox="0 0 20 20"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="text-green-500 dark:text-green-500 mr-1 transform rotate-45"
          width="14"
          height="14"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L4.707 9.707a1 1 0 01-1.414 0z"
            fill="currentColor"
          ></path>
        </svg>
      )
    case n < 0:
      return (
        <svg
          viewBox="0 0 20 20"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="text-red-400 dark:text-red-500 mr-1 transform  rotate-45"
          width="14"
          height="14"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
            fill="currentColor"
          ></path>
        </svg>
      )
    default:
      return ""
  }
}

const colorFor = (n) => {
  switch (true) {
    case n > 0:
      return "green"
    case n < 0:
      return "red"
    default:
      return "gray"
  }
}

function DisplayNumber(props) {
  let { price, change } = props

  return <div className="p-2">
    <div className="">Ξ{price.toFixed(2)}</div>
    <div className="flex flex-row items-center">
      {svgFor(change)}
      <span
        className={`text-xs font-semibold text-${colorFor(
          change
        )}-500`}
      >
        {(change || 0).toFixed(2)}%
      </span>
    </div>
  </div>
}

const TOP_SALES = gql`query getTopSales($seconds: Int) {
  topSales(seconds: $seconds) {
    slug
    name
    image
    sales
    floorPrice
    max
    averagePrice
    volume
    floorPriceChange
    salesChange
    averagePriceChange
    volumeChange
  }
}`;

// function format(n) {
//   return 'Ξ' + n.toFixed(2).replace(/0+$/, '').replace(/\.$/, '')
// }

function Top() {
  const [sort, setSort] = useState('sales')
  const [asc, setAsc] = useState(false)
  const [seconds, setSeconds] = useState(3600)
  const { data, refetch } = useQuery(TOP_SALES, {
    variables: { seconds }
  })

  let topSales = data?.topSales
  if (topSales) {
    if (asc) {
      topSales = [...topSales].sort((a, b) => a[sort] - b[sort])
    } else {
      topSales = [...topSales].sort((a, b) => b[sort] - a[sort])
    }
  }

  //.sort((a, b) => a[sort] - b[sort])


  useEffect(() => {
    refetch()
    // eslint-disable-next-line
  }, [seconds])

  return <div className="w-full mt-2">
    <div className="flex flex-row">
      <LeftNav />
      <div className="w-full m-4">
        <div className="flex">
          <div className="flex-1"></div>
          <div className="flex-0 text-xs mr-32 mb-2">
            <button onClick={() => setSeconds(300)} className={`${seconds === 300 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>5m</button>
            <button onClick={() => setSeconds(900)} className={`${seconds === 900 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>15m</button>
            <button onClick={() => setSeconds(1800)} className={`${seconds === 1800 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>30m</button>
            <button onClick={() => setSeconds(3600)} className={`${seconds === 3600 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>1h</button>
            <button onClick={() => setSeconds(7200)} className={`${seconds === 7200 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>2h</button>
            <button onClick={() => setSeconds(21600)} className={`${seconds === 21600 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>6h</button>
            <button onClick={() => setSeconds(43200)} className={`${seconds === 43200 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>12h</button>
            <button onClick={() => setSeconds(86400)} className={`${seconds === 86400 ? 'bg-blue-700' : 'bg-custom-500'} rounded text-white w-8 ml-1 h-6`}>24h</button>
          </div>
        </div>
        {data ?
          <table className="w-full table-auto dark:text-white">
            <thead>
              <tr className="cursor-pointer">
                <td></td>
                <td onClick={() => sort === 'name' ? setAsc(!asc) : setSort('name')} className="font-bold ">Collection</td>
                <td onClick={() => sort === 'floorPrice' ? setAsc(!asc) : setSort('floorPrice')} className="font-bold ">Sales Floor</td>
                <td onClick={() => sort === 'sales' ? setAsc(!asc) : setSort('sales')} className="font-bold ">Sales</td>
                <td onClick={() => sort === 'averagePrice' ? setAsc(!asc) : setSort('averagePrice')} className="font-bold ">Average</td>
                <td onClick={() => sort === 'volume' ? setAsc(!asc) : setSort('volume')} className="font-bold ">Volume</td>
              </tr>
            </thead>
            <tbody>
              {topSales.map((ts, i) => <tr key={i}>
                <td className="py-1"><img src={ts.image} className="w-8 h-8 rounded-full" alt="collection"/></td>
                <td className="py-1"><Link to={`/collection/${ts.slug}`}>{ts.name}</Link></td>


                <td className="py-1"><DisplayNumber price={ts.floorPrice} change={ts.floorPriceChange} /></td>
                <td className="py-1"><DisplayNumber price={ts.sales} change={ts.salesChange} /></td>
                <td className="py-1"><DisplayNumber price={ts.averagePrice} change={ts.averagePriceChange} /></td>
                <td className="py-1"><DisplayNumber price={ts.volume} change={ts.volume} /></td>


              </tr>)}
            </tbody>
          </table> : <div className="w-full text-8xl p-20 text-center">Loading</div>}
      </div>

      {/* {JSON.stringify(data)} */}
    </div>
  </div>
}

export default Top