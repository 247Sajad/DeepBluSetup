
import { Link } from "react-router-dom";


function LeftNav() {

  return <div className="w-48 border-r min-h-screen dark:bg-gray-700">
    <Link className="w-full p-2 text-center hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-white block" to="/">Home</Link>
    <Link className="w-full p-2 text-center hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-white block" to="/top">Top 50</Link>
    <Link className="w-full p-2 text-center hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-white block" to="/trending">Trending</Link>
    <Link className="w-full p-2 text-center hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-white block" to="/market_updates">Matket Updates</Link>
    <Link className="w-full p-2 text-center hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-white block" to="/collection/otherdeed">Collection</Link>

  </div>
}

export default LeftNav