import Candlestick from './apex/Candlestick'
import OSVolume from './apex/OSVolume'
import Scatter from './apex/Scatter'
import Treemap from './apex/Treemap'
import LeftNav from './LeftNav'




function Home(){

  return <div className="w-full mt-2">

  <div className="flex flex-row">
    <LeftNav/>
    <div className="flex-1 bg-gray-50 dark:bg-gray-800">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
        <div><OSVolume /></div>
        <div><Candlestick /></div>
        <div><Scatter /></div>

        {/* <div><Bar/></div> */}
      </div>
      <div className="p-2"><Treemap num={10}/></div>
    </div>
  </div>
</div>
}

export default Home