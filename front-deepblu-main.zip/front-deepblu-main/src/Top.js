import Treemap from './apex/Treemap'
import LeftNav from './LeftNav'



function Top() {
  return <div className="w-full mt-2">
    <div className="flex flex-row">
      <LeftNav />
      <div className="flex-1 bg-gray-50 dark:bg-gray-800">
        <div className="p-2"><Treemap num={50} /></div>
      </div>
    </div>
  </div>
}

export default Top