import { useState, useEffect } from 'react' // , { useState }
import { useParams } from "react-router-dom";
import LeftNav from './LeftNav'
import Candlestick from './am/Candlestick'
import Bubble from './am/Bubble'

import { FaDiscord, FaTwitter, FaInstagram } from 'react-icons/fa';

function Collection() {
  let { slug } = useParams()
  let [collectionData, setCollectionData] = useState({})

  let {
    banner_image_url,
    description,
    name,
    discord_url,
    twitter_username,
    instagram_username,
    // stats,
    // external_url,
    // telegram_url,
    // wiki_url,
  } = collectionData

  useEffect(() => {
    fetch(`https://api.opensea.io/api/v1/collection/${slug}`).then(r => r.json()).then(data => setCollectionData(data.collection))
  }, [slug])

  return <div className="w-full mt-2">
    <div className="flex flex-row">
      <LeftNav />
      <div className="flex-1 bg-gray-50 dark:bg-gray-800">
        <div style={{backgroundImage: `url(${banner_image_url})`}} className="text-gray-200 bg-cover">
          <div className="bg-opacity-60 bg-black">
          <div className="flex">
            <div className="w-96 p-4">
              <div className="text-xl font-bold">{name}</div>
              <div className="mt-2">{description}</div>

            </div>
            <div className="flex-1"></div>
            <div className="flex-0 flex self-end m-2">
              {discord_url && <div><a href={discord_url}><FaTwitter size="36" /></a></div>}
              {twitter_username && <div><a href={`https://twitter.com/${twitter_username}`}><FaDiscord size="36" /></a></div>}
              {instagram_username && <div><a href={`https://instagram.com/${instagram_username}`}><FaInstagram size="36" /></a></div>}
            </div>
          </div>
          </div>
        </div>
        <div className="p-2">
          <Bubble name={name} slug={slug}/>
          <Candlestick name={name} slug={slug}/>
          {slug}
          {collectionData && <div>
            {/* {JSON.stringify(Object.keys(collectionData))} */}
          </div>}
        </div>
      </div>
    </div>
  </div>
}

export default Collection


/*
  editors
  payment_tokens
  primary_asset_contracts
  traits
  chat_url
  created_date
  default_to_fiat
  dev_buyer_fee_basis_points
  dev_seller_fee_basis_points
  display_data
  featured
  featured_image_url
  hidden
  safelist_request_status
  image_url
  is_subject_to_whitelist
  large_image_url
  medium_username
  only_proxied_transfers
  opensea_buyer_fee_basis_points
  opensea_seller_fee_basis_points
  payout_address
  require_email
  short_description
  slug
  is_nsfw
*/