import LeftNav from './LeftNav'
// import React, { useState, useEffect } from 'react' // , { useState }
import { useQuery, gql } from '@apollo/client';
import { DiscordMessage, DiscordMessages } from '@danktuary/react-discord-message';

const TOP_SALES = gql`query getDiscordMessages($limit: Int) {
  discordMessages(limit: $limit) {
    username
    user_id
    avatar
    content
    attachments
    createdAt
    images
  }
}`;

function MarketUpdates() {
  const { data } = useQuery(TOP_SALES, { // , refetch
    // variables: { seconds }
  })




  //.sort((a, b) => a[sort] - b[sort])


  // useEffect(() => {
  //   refetch()
  //   // eslint-disable-next-line
  // }, [seconds])

  return <div className="w-full mt-2">
    <div className="flex flex-row">
      <LeftNav />
      <div className="w-full m-4">

        {data ? <DiscordMessages>
          {data.discordMessages.map((dm, i) => <DiscordMessage key={i} timestamp={dm.createdAt * 1000} bot={false} author={dm.username} avatar={dm.avatar ? `https://cdn.discordapp.com/avatars/${dm.user_id}/${dm.avatar}.webp?size=80` : undefined} roleColor="violet">
            <div>{dm.content}</div>
            {dm.attachments.map((url, i) => <img key={i} src={url} alt={`Attachment ${i}`} />)}
          </DiscordMessage>)}
        </DiscordMessages>
          : <div className="w-full text-8xl p-20 text-center">Loading</div>}
      </div>

      {/* {JSON.stringify(data)} */}
    </div>
  </div>
}

export default MarketUpdates
