import React from 'react' // , { useState }
import './App.css';
import Home from './Home'
import Top from './Top'
import Trending from './Trending'
import MarketUpdates from './MarketUpdates'
import Collection from './Collection'

// import Bar from './chart/Bar'
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom"

import Nav from './Nav'
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client'

const client = new ApolloClient({
  // uri: 'http://localhost:4000',
  uri: 'https://api.deepblu.io/graphql',
  cache: new InMemoryCache(),
});

function App() {

  return <ApolloProvider client={client}>
    <Router>
      <Nav />
      <Routes>
        <Route path="/trending" element={<Trending />} />
        <Route path="/collection/:slug" element={<Collection />} />
        <Route path="/market_updates" element={<MarketUpdates />} />
        <Route path="/top" element={<Top />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </Router>
  </ApolloProvider>
}

export default App;
