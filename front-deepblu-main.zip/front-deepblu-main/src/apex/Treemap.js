import React, {useState, useEffect} from 'react' // , { useState }
import Chart from "react-apexcharts";
import { useQuery, gql } from '@apollo/client';

import {
  Link,
} from "react-router-dom";

const VOLUME = gql`query getTrending($sort: String, $num: Int) {
  trending(sort: $sort, num: $num) {
    slug
    name
    one_day_volume
    one_day_sales
  }
}`;

function Treemap(props) {
  let {num} = props
  num = num || 50
  const [sort, setSort] = useState('one_day_volume')
  const { loading, error, data, refetch } = useQuery(VOLUME, {
    variables: {sort, num}
  })

  useEffect(() => {
    refetch()
    // eslint-disable-next-line
  }, [sort])

  const state = {
    options: {
      enableShades: false,
      shadeIntensity: 0.5,
      reverseNegativeShade: true,
      distributed: false,
      useFillColorAsStroke: false,
      chart: {
        toolbar: { show: false },
        type: 'treemap',
        events: {
          click: ((a, b, o) => {
            console.log(data.trending[o.dataPointIndex].slug)
          })
        },
        enableShades: false,
        shadeIntensity: 0.5,
        reverseNegativeShade: true,
        distributed: false,
        useFillColorAsStroke: false,
        colorScale: {
          ranges: [{
              from: 0,
              to: 99999,
              color: '#5A6FC0',
              foreColor: '#5A6FC0',
              name: '#5A6FC0',
          }],
          inverse: false,
        },
      },
      // title: {
      //   text: 'Treemap'
      // },
      xaxis: {
        categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999]
      },
      fill: {
        colors: ['#5A6FC0', '#5A6FC0', '#5A6FC0']
      },

    //   dataLabels: {
    //     style: {
    //       colors: ['#5A6FC0', '#5A6FC0', '#5A6FC0']
    //     }
    //   },
      markers: {
        colors: ['#5A6FC0', '#5A6FC0', '#5A6FC0']
     },
     annotations: {
      position: 'back',
      images: [{ path: '/watermark.png', width: 200, height: 200, x: 10, y: 10 }]
     }

    },
    series: [
      {
        data: loading || error ? [] : data.trending.map(row => {
          return {
            x: row.name,
            y: row.one_day_volume
          }
        })
      }
    ]
  }

  let { options, series } = state
  let active = 'inline-block p-4 text-custom-500 rounded-t-lg border-b-2 border-custom-500 active dark:text-blue-500 dark:border-blue-500'
  let inactive = 'inline-block p-4 rounded-t-lg text-black dark:text-white' //  dark:border-blue-500

  return loading || error ? <></> : <div>
    <div className="flex">
      <ul className="flex flex-wrap">
        <li className="mr-2">
          <button onClick={() => setSort('one_day_volume')} href="#" className={sort === 'one_day_volume' ? active : inactive}>Volume</button>
        </li>
        <li className="mr-2">
          <button onClick={() => setSort('one_day_sales')} href="#" className={sort === 'one_day_sales' ? active : inactive}>Sales</button>
        </li>
      </ul>
      {num < 50 && <Link className="bg-custom-500 text-white py-1 px-2 rounded" to="/top">View All</Link>}

    </div>
    <div className="row">
      <div className="mixed-chart">
        <Chart
          // title="Treemap"
          options={options}
          series={series}
          legend={{ show: false }}
          type="treemap"
          width="100%"
          height="800"
        />
      </div>
    </div>
    {/* {JSON.stringify(data.trending)} */}
  </div>
}

export default Treemap