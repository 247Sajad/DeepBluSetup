function getStockData(rows, hours=24){
  let points = {}
  for (let row of rows) {
    let { price, created_date } = row
    let ts = Number(created_date)
    let day = Math.floor(ts / 1000 / 60 / 60 / 24)
    let hour = hours === 1 ? new Date(ts).getHours() : 0
    let key = `${day}:${hour}`
    let oldPoint = points[key]
    if (oldPoint) {
      oldPoint.Volume += price
      if(ts < oldPoint.first){
        // debugger
        oldPoint.first = ts
        oldPoint.Open = price
      }
      if(ts > oldPoint.last){
        // debugger
        oldPoint.last = ts
        oldPoint.Close = price
      }
      if(price > oldPoint.High){
        oldPoint.High = price
        // debugger
      }
      if(price < oldPoint.Low){
        oldPoint.Low = price
        // debugger
      }
      // debugger
    } else {
      let d = new Date(ts)
      d.setMinutes(0)
      d.setSeconds(0)
      d.setMilliseconds(0)
      points[key] = {
        Date: d.getTime(),
        first: ts,
        last: ts,
        Open: price,
        High: price,
        Low: price,
        Close: price,
        Volume: price
      }
    }
  }
  return Object.values(points)
}

export default getStockData