import React, { useState, useEffect } from 'react' // , { useState }
import Chart from "react-apexcharts";
import { useQuery, gql } from '@apollo/client';

const VOLUME = gql`query getVolume($hours: Int!) {
  volume(hours: $hours){
    date,
    volume
  }
}`;

function OSVolume(props) {
  const [hours, setHours] = useState(1)
  const {  data, refetch } = useQuery(VOLUME, {
    variables: {hours}
  })

  useEffect(() => {
    refetch()
    // eslint-disable-next-line
  }, [hours])

  const options = {
    fill: {
      colors: ['#5A6FC0', '#5A6FC0', '#5A6FC0']
    },
    chart: {
      toolbar: { show: false },

    },
    // title: {
    //   text: 'Bar'
    // },
    xaxis: {
      categories: data ? data.volume.map(v => new Date(v.date * 1000).toLocaleString().replace('/2022', '').replace(/:\d{2} .*/, '') ) : []
    },
    dataLabels: {
      enabled: false,
    },
    yaxis: {
      decimalsInFloat: 0,
      labels: {
        formatter: (v) => { return 'Ξ' + (v / 1000).toFixed(0) + 'K' },
      }
    },
    annotations: {
      position: 'back',
      images: [{ path: '/watermark.png', width: 200, height: 200, x: 10, y: 10 }]
     }
  }

  const series = [
    {
      name: "Volume",
      data: data ? data.volume.map(v => v.volume) : []
    }
  ]


  return <div className="app">
    <select onChange={e => setHours(Number(e.target.value))} defaultValue={hours}>
      <option value={24}>24 Hours</option>
      <option value={12}>12 Hours</option>
      <option value={4}>4 Hours</option>
      <option value={1}>1 Hours</option>
    </select>
    <div className="row">
      <div className="mixed-chart">
        <Chart
          options={options}
          series={series}
          type="bar"
          width="100%"
        />
      </div>
    </div>
    {/* {JSON.stringify(data?.volume.map(v => new Date(v.date * 1000).toLocaleString()))} */}
  </div>
}

export default OSVolume